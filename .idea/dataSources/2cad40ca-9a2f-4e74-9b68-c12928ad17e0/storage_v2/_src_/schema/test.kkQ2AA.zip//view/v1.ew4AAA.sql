CREATE VIEW v1 AS
  SELECT `test`.`student`.`Sname` AS `sname`
  FROM `test`.`student`
  WHERE ((2018 - `test`.`student`.`Sage`) > 1990);

