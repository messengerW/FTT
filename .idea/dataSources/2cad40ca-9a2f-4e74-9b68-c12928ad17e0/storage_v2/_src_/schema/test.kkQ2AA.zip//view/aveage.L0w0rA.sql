CREATE VIEW aveage AS
  SELECT
    `test`.`student`.`Clno`      AS `Clno`,
    avg(`test`.`student`.`Sage`) AS `avgage`
  FROM `test`.`student`;

