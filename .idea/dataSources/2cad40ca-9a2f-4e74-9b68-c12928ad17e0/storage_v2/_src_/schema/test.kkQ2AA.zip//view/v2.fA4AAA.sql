CREATE VIEW v2 AS
  SELECT
    `test`.`student`.`Sno`           AS `sno`,
    `test`.`student`.`Sname`         AS `sname`,
    (2018 - `test`.`student`.`Sage`) AS `YEAR`
  FROM `test`.`student`
  WHERE `test`.`student`.`Sno` IN (SELECT `test`.`grade`.`Sno`
                                   FROM `test`.`grade`
                                   WHERE ((`test`.`grade`.`Cno` = 1) AND (`test`.`grade`.`Gmark` < 60)));

