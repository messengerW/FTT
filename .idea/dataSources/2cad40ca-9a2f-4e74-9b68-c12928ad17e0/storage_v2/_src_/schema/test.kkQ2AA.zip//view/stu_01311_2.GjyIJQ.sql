CREATE VIEW stu_01311_2 AS
  SELECT
    `test`.`student`.`Sno`   AS `Sno`,
    `test`.`student`.`Sname` AS `Sname`,
    `test`.`student`.`Ssex`  AS `Ssex`,
    `test`.`student`.`Sage`  AS `Sage`,
    `test`.`student`.`Clno`  AS `Clno`
  FROM `test`.`student`
  WHERE (`test`.`student`.`Sno` IN (SELECT `test`.`grade`.`Sno`
                                    FROM `test`.`grade`
                                    WHERE ((`test`.`grade`.`Cno` = '1') AND (`test`.`grade`.`Gmark` < 60))) AND
         (`test`.`student`.`Clno` = '01311'));

