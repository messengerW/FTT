CREATE VIEW v3 AS
  SELECT
    `test`.`student`.`Clno`       AS `Clno`,
    count(`test`.`student`.`Sno`) AS `num`
  FROM `test`.`student`
  GROUP BY `test`.`student`.`Clno`
  HAVING (`num` > 4);

