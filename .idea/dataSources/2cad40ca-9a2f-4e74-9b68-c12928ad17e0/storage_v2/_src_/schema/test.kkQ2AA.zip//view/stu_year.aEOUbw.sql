CREATE VIEW stu_year AS
  SELECT
    `test`.`student`.`Sno`           AS `Sno`,
    `test`.`student`.`Sname`         AS `Sname`,
    (2018 - `test`.`student`.`Sage`) AS `birthday`
  FROM `test`.`student`;

